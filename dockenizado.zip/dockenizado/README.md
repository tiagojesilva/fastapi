README

Na raiz do projeto:

docker-compose up --build

se quiser povoar o bd:

docker-compose exec api python povoar_bd.py

