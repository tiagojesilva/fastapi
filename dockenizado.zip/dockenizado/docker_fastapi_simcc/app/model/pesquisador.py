from pydantic import BaseModel

class Pesquisador(BaseModel):
    pesquisadores_id: str
    lattes_id: str
    nome: str

    class Config:
        from_attributes = True


