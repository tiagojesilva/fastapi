from pydantic import BaseModel

class Producao(BaseModel):
    producao_id: str
    pesquisadores_id: str
    nomeartigo: str
    issn: str
    anoartigo: int

    class Config:
        from_attributes = True

