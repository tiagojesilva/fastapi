from fastapi import APIRouter, HTTPException
from typing import List
from model.producao import Producao
from dao.producoes_dao import (
    listar_todos,
    salvar_nova_producao,
    atualizar_por_id,
    apagar_por_producao_id
)

producao_router = APIRouter()

@producao_router.get("/producoes", response_model=List[Producao])
def listar():
    return listar_todos()

@producao_router.post("/producoes", response_model=Producao)
def adicionar(producao: Producao):
    resposta = salvar_nova_producao(producao)
    if 'Erro' in resposta:
        raise HTTPException(status_code=400, detail=resposta)
    return producao

@producao_router.put("/producoes", response_model=Producao)
def atualizar(producao: Producao):
    resposta = atualizar_por_id(producao)
    if 'Erro' in resposta:
        raise HTTPException(status_code=400, detail=resposta)
    return producao

@producao_router.delete("/producoes/{producao_id}", response_model=str)
def apagar(producao_id: str):
    resposta = apagar_por_producao_id(producao_id)
    if 'inválido' in resposta:
        raise HTTPException(status_code=400, detail=resposta)
    return resposta

