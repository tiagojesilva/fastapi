from banco import conexao_singleton as cs
from model.producao import Producao
from typing import List

conexao = cs.Conexao().get_conexao()

def salvar_nova_producao(producao: Producao) -> str:
    sql = """
        INSERT INTO producoes (nomeartigo, anoartigo, pesquisadores_id, issn)
        VALUES (%s, %s, %s, %s)
    """
    try:
        with conexao.cursor() as cursor:
            cursor.execute(sql, (
                producao.nomeartigo,
                producao.anoartigo,
                producao.pesquisadores_id,
                producao.issn
            ))
            conexao.commit()
        return "Nova Produção salva com sucesso!"
    except Exception as e:
        conexao.rollback()
        return f"Erro ao salvar: {e}"

def listar_todos() -> List[Producao]:
    sql = """
        SELECT 
            producoes_id AS producao_id,
            nomeartigo,
            anoartigo,
            pesquisadores_id,
            issn
        FROM producoes
    """
    with conexao.cursor() as cursor:
        cursor.execute(sql)
        resultado = cursor.fetchall()
        colunas = [desc[0] for desc in cursor.description]
        dados = [dict(zip(colunas, linha)) for linha in resultado]
        return [Producao(**d) for d in dados]


def atualizar_por_id(producao: Producao) -> str:
    sql = """
        UPDATE producoes
        SET nomeartigo = %s, issn = %s, anoartigo = %s
        WHERE producoes_id = %s
    """
    try:
        with conexao.cursor() as cursor:
            cursor.execute(sql, (
                producao.nomeartigo,
                producao.issn,
                producao.anoartigo,
                producao.producao_id
            ))
            if cursor.rowcount == 0:
                raise Exception("Nenhum registro atualizado.")
            conexao.commit()
        return "Produção atualizada com sucesso!"
    except Exception as e:
        conexao.rollback()
        return f"Erro ao atualizar produção: {e}"

def apagar_por_producao_id(producao_id: str) -> str:
    sql = "DELETE FROM producoes WHERE producoes_id = %s"
    try:
        with conexao.cursor() as cursor:
            cursor.execute(sql, (producao_id,))
            if cursor.rowcount == 0:
                raise Exception("Produção inexistente ou ID inválido.")
            conexao.commit()
        return "Produção apagada com sucesso!"
    except Exception as e:
        conexao.rollback()
        return f"Erro ao apagar produção: {e}"

