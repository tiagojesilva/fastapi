import os
import psycopg2

class Conexao:
    _instancia = None

    def __init__(self):
        if not Conexao._instancia:
            print("Classe Conexao inicializada!")

            self.conn = psycopg2.connect(
                host=os.getenv("DB_HOST", "localhost"),
                database=os.getenv("DB_NAME", "meu_banco"),
                user=os.getenv("DB_USER", "usuario"),
                password=os.getenv("DB_PASSWORD", "senha"),
                port=5432
            )
            print("Conexão estabelecida!")
            Conexao._instancia = self
        else:
            self.conn = Conexao._instancia.conn

    def get_conexao(self):
        return self.conn

