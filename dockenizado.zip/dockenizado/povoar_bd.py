import psycopg2
import os

def povoar():
    conn = psycopg2.connect(
        dbname=os.getenv("POSTGRES_DB", "simcc"),
        user=os.getenv("POSTGRES_USER", "postgres"),
        password=os.getenv("POSTGRES_PASSWORD", "postgres"),
        host=os.getenv("POSTGRES_HOST", "db"),
        port=os.getenv("POSTGRES_PORT", "5432")
    )

    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS pesquisadores (
        pesquisadores_id UUID PRIMARY KEY,
        nome TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS producoes (
        producoes_id UUID PRIMARY KEY,
        pesquisadores_id UUID REFERENCES pesquisadores(pesquisadores_id),
        nomeartigo TEXT NOT NULL,
        issn TEXT NOT NULL,
        anoartigo INT NOT NULL
    );
    """)

    conn.commit()
    cur.close()
    conn.close()

if __name__ == "__main__":
    povoar()
